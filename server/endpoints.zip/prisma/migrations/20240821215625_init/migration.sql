-- AlterTable
ALTER TABLE "workspace_chats" ADD COLUMN "api_session_id" TEXT;
