-- AlterTable
ALTER TABLE "workspace_chats" ADD COLUMN "feedbackScore" BOOLEAN;
